import argparse

parser = argparse.ArgumentParser(description="Add two integers")

parser.add_argument("num1", type=int, help="First Integer")
parser.add_argument("num2", type=int, help="Second Integer")
args = parser.parse_args()

print(args.num1 + args.num2)