import sys

if len(sys.argv) != 3:
    print("Usage: python sum.py <num1> <num2>")
    raise SystemExit(1)

try:
    a = int(sys.argv[1])
    b = int(sys.argv[2])
except ValueError:
    print("Both arguments must be integers")
    raise SystemExit(1)

print(a + b)