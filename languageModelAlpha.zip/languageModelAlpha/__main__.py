from .sentGenerator import genSentence

if __name__ == '__main__':
    print(genSentence())