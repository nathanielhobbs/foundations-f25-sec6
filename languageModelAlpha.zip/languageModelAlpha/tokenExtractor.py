from .cli import file_name

def tokenExtractor(lines):
    tokens = []
    for s in lines:
        tokens.extend(s.split())
    return tokens

with open(file_name, 'r') as f:
    lines = f.readlines()

tokens = tokenExtractor(lines)

